#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_DRIVER_SIZE 50
#define MAX_SEASON_SIZE 50
#define MAX_RACES 50


typedef struct driver{
    char firstName[10];
    char lastName[10]; 
    int points; 
    int number;
    char team[10];
    int age; 
    int year;
} driver_t; 

typedef struct {
    driver_t driverList[MAX_DRIVER_SIZE]; 
    int number_of_drivers; 
} driverList;

typedef struct race{
    char date[11];
    char location[30];
    char raceNumber[10];
    int numberOfLaps; 
    char P1[10];
    char P2[10];
    char P3[10]; 
} race_t; 

typedef struct {
    race_t racesList[MAX_SEASON_SIZE]; 
    int number_of_races; 
}   racesList;


void printMenu(racesList *races, driverList *drivers);
void displayAllResults(int number_of_races, race_t *races, driverList *drivers);
void displayAllDrivers(driverList *drivers);


int main(void){
    racesList races;
    driverList drivers;
    int choice;
    do {
        printMenu(&races, &drivers);
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                displayAllResults(races.number_of_races, races.racesList, &drivers);
                break;
            case 2:
                printf("choice 1");
                break;
            case 3:
                printf("choice 1");
                break;
            case 4:
                printf("choice 1");
                break;
            case 5:
                displayAllDrivers(&drivers);
                break;
            case 6:
                printf("choice 1");
                break;
            case 7:
                printf("choice 1");
                break;
            case 8:
                printf("choice 1");
                break;
            case 9:
                break;
            default:
                printf("Invalid choice. Please enter a number between 1 and 9.\n");
                break;
        }
    } while (choice != 6);
    return 0;
}


/************
This function prints the user menu (Alexia)
inputs: none 
outputs: none
*************/ 

void printMenu(racesList *races, driverList *drivers) {
    printf("----------------------\n");
    printf("F1 Race Results Finder\n");
    printf("----------------------\n");
    printf("1. Display all race results\n");
    printf("2. Add race results\n");
    printf("3. Remove race results\n");
    printf("4. Save race results to database\n");
    printf("5. Display all drivers and their results\n");
    printf("6. Calculate World Champion\n");
    printf("7. Display all teams and their results\n");
    printf("8. Calculate Constructors' Champion\n");
    printf("9. Exit\n \n");
    printf("Please enter your choice (1-9): ");
}

/************
This function gets the total list of races (Ji Hyun)
inputs: from data  
outputs: list of all races over the period  
*************/ 

void displayAllResults(int number_of_races, race_t *races, driverList *drivers) {
    FILE *file = fopen("f1driver.txt", "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    drivers->number_of_drivers = 0;

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char *token = strtok(line, ",");
        if (token == NULL) continue;

        strcpy(drivers->driverList[drivers->number_of_drivers].firstName, token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        strcpy(drivers->driverList[drivers->number_of_drivers].lastName, token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        drivers->driverList[drivers->number_of_drivers].points = atoi(token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        drivers->driverList[drivers->number_of_drivers].number = atoi(token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        strcpy(drivers->driverList[drivers->number_of_drivers].team, token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        drivers->driverList[drivers->number_of_drivers].year = atoi(token);
  
        drivers->number_of_drivers++;
    }
    fclose(file);
    printf("\nAll Results\n");
    printf("-------------------------------------------------------------------------\n");
    printf("%-20s %-20s %-10s %-10s %-20s\n", "Firstname", "Lastname", "Points", "Number", "Team");
    printf("-------------------------------------------------------------------------\n");
    for (int i = 0; i < drivers->number_of_drivers; i++) {
        printf("%-20s %-20s %-10d %-10d %-20s\n", drivers->driverList[i].firstName, drivers->driverList[i].lastName, drivers->driverList[i].points, drivers->driverList[i].number, drivers->driverList[i].team);
    }
}

/************
This function adds to the total list of races (Darren)
inputs: race structs from user   
outputs: none   
*************/ 

void addRaceResults(racesList *list){

}

/************
This function removes the last race from total list of races (Aiden)
inputs: race structs from user   
outputs: none   
*************/ 

void removeRaceResults(racesList *list) {
    if (list->number_of_races > 0) {
        list->number_of_races--;
        printf("Last race results removed successfully.\n");
    } else {
        printf("No races to remove.\n");
    }
}



/************
This function saves the race results to the database (Alexia)
inputs: race list from user   
outputs: none   
*************/ 

void saveRaceResultstoDatabase(racesList *list, const char *filename){

}



/************
This function prints all of the drivers, and their results from each race in the selected year (Ji Hyun)
inputs: year  
outputs: list of all drivers, with their podium stats and points. 
*************/ 

void displayAllDrivers(driverList *drivers) {
    printf("\nAll Drivers\n");
    FILE *file = fopen("f1driver.txt", "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    drivers->number_of_drivers = 0;

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char *token = strtok(line, ",");
        if (token == NULL) continue;

        char firstName[20];
        char lastName[20];
        strcpy(firstName, token);

        token = strtok(NULL, ",");
        if (token == NULL) continue;
        strcpy(lastName, token);

        int points;
        token = strtok(NULL, ",");
        if (token == NULL) continue;
        points = atoi(token);

        int number;
        token = strtok(NULL, ",");
        if (token == NULL) continue;
        number = atoi(token);

        char team[20];
        token = strtok(NULL, ",");
        if (token == NULL) continue;
        strcpy(team, token);

        int i;
        int found = 0;
        for (i = 0; i < drivers->number_of_drivers; i++) {
            if (strcmp(drivers->driverList[i].firstName, firstName) == 0 &&
                strcmp(drivers->driverList[i].lastName, lastName) == 0) {
                drivers->driverList[i].points += points;
                found = 1;
                break;
            }
        }

        if (!found) {
            strcpy(drivers->driverList[drivers->number_of_drivers].firstName, firstName);
            strcpy(drivers->driverList[drivers->number_of_drivers].lastName, lastName);
            drivers->driverList[drivers->number_of_drivers].points = points;
            drivers->driverList[drivers->number_of_drivers].number = number;
            strcpy(drivers->driverList[drivers->number_of_drivers].team, team);
            drivers->number_of_drivers++;
        }
    }
    fclose(file);
    printf("-------------------------------------------------------------------------\n");
    printf("%-20s %-20s %-10s %-10s %-20s\n", "Firstname", "Lastname", "Points", "Number", "Team");
    printf("-------------------------------------------------------------------------\n");
    for (int i = 0; i < drivers->number_of_drivers; i++) {
        printf("%-20s %-20s %-10d %-10d %-20s\n", drivers->driverList[i].firstName,
               drivers->driverList[i].lastName, drivers->driverList[i].points,
               drivers->driverList[i].number, drivers->driverList[i].team);
    }
}

/************
This function displays the driver with the most points for the selected year (Darren)
inputs: year  
outputs: the world champion driver with a photo
*************/ 

void calculateWorldChampion(){

}

/************
This function prints all teams, and their results in the selected year. (Aiden)
inputs: year 
outputs: list of the teams of that particular year, with their constructors points. 
*************/ 

void displayAllTeams(driverList *drivers, int year){
    printf("ALL Team Results in year %d\n", year);
    for(int i = 0; i < drivers->number_of_drivers; i++){
        if(drivers->driverList[i].year == year){
            printf("%s\n", drivers->driverList[i].team);
            printf("%d\n", drivers->driverList[i].points);
        }
    }
}

/************
This function displays the team with the most points for the selected year (Alexia)
inputs: year  
outputs: the world champion team, with a photo
*************/ 

void calculateConstructorsChampion(){

}
